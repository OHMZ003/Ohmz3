# Model adapter placeholder
