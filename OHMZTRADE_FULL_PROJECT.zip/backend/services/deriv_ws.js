// Deriv websocket placeholder
