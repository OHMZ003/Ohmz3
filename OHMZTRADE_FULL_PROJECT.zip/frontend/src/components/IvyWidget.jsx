// Ivy AI widget placeholder
