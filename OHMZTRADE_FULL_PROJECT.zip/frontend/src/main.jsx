// React entry placeholder
