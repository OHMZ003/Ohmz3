// MT5 adapter placeholder
